import Formulaire from '../components/formulaire'
function Ex4() {
    return(
        <Formulaire />
    )
}

export default Ex4;