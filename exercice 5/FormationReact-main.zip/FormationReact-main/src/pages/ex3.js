import Magasin from '../components/magasin';

function Ex3() {
    return(
        <div>
             <h2>Ex3</h2>
            <Magasin liste_achats="item1,item2,item3" panier="item1,item2,item3" total="total" />
        </div>
    );
}

export default Ex3;