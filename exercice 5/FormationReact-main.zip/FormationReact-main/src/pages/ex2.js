import Table from '../components/table';

function Ex2() {
    return(
        <div>
            <h2>Ex2</h2>
            <Table ligne="c est une ligne" colonne="c est une colonne" />
        </div>
    );
}

export default Ex2;